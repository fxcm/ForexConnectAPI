#include "stdafx.h"
#include "ResponseListener.h"
#include "SessionStatusListener.h"
#include "LoginParams.h"
#include "SampleParams.h"
#include "CommonSources.h"

void printHelp(std::string &);
bool checkObligatoryParams(LoginParams *, SampleParams *);
void printSampleParams(std::string &, LoginParams *, SampleParams *);
IO2GOfferRow *getOfferAndPrint(IO2GSession *, const char *);
IO2GRequest *createSetSubscriptionStatusRequest(IO2GSession *, const char *, const char *, ResponseListener *);

int main(int argc, char *argv[])
{
    std::string procName = "Unsubscribe";
    if (argc == 1)
    {
        printHelp(procName);
        return -1;
    }

    bool bWasError = false;

    LoginParams *loginParams = new LoginParams(argc, argv);
    SampleParams *sampleParams = new SampleParams(argc, argv);

    printSampleParams(procName, loginParams, sampleParams);
    if (!checkObligatoryParams(loginParams, sampleParams))
    {
        delete loginParams;
        delete sampleParams;
        return -1;
    }

    IO2GSession *session = CO2GTransport::createSession();

    SessionStatusListener *sessionListener = new SessionStatusListener(session, true,
                                                                       loginParams->getSessionID(),
                                                                       loginParams->getPin());
    session->subscribeSessionStatus(sessionListener);

    bool bConnected = login(session, sessionListener, loginParams);

    if (bConnected)
    {
        ResponseListener *responseListener = new ResponseListener(session);
        session->subscribeResponse(responseListener);


        if (!session)
            return NULL;

        IO2GOfferRow* resultOffer = NULL;
        O2G2Ptr<IO2GLoginRules> loginRules = session->getLoginRules();
        if (loginRules)
        {
            O2G2Ptr<IO2GResponse> response = loginRules->getTableRefreshResponse(Offers);
            if (response)
            {
                O2G2Ptr<IO2GResponseReaderFactory> readerFactory = session->getResponseReaderFactory();
                if (readerFactory)
                {
                    O2G2Ptr<IO2GOffersTableResponseReader> reader = readerFactory->createOffersTableReader(response);
                    for (int i = 0; i < reader->size(); ++i)
                    {
                        O2G2Ptr<IO2GOfferRow> offer = reader->getRow(i);
                        if (offer)
                        {
                            O2G2Ptr<IO2GRequest> request = createSetSubscriptionStatusRequest(session, offer->getOfferID(), sampleParams->getStatus(), responseListener);

                            if (request)
                            {
                                responseListener->setRequestID(request->getRequestID());
                                session->sendRequest(request);
                                if (responseListener->waitEvents())
                                {
                                    O2G2Ptr<IO2GResponse> response = responseListener->getResponse();
                                    if (response && response->getType() == CommandResponse)
                                    {
                                        printf("Subscription status for '%s' is set to '%s'\n", offer->getInstrument(), sampleParams->getStatus());
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }



        session->unsubscribeResponse(responseListener);
        responseListener->release();
        logout(session, sessionListener);
    }
    else
    {
        bWasError = true;
    }

    session->unsubscribeSessionStatus(sessionListener);
    sessionListener->release();
    session->release();

    delete loginParams;
    delete sampleParams;

    if (bWasError)
        return -1;
    return 0;
}


IO2GOfferRow *getOfferAndPrint(IO2GSession *session, const char *sInstrument)
{
    if (!session || !sInstrument)
        return NULL;

    IO2GOfferRow *resultOffer = NULL;
    O2G2Ptr<IO2GLoginRules> loginRules = session->getLoginRules();
    if (loginRules)
    {
        O2G2Ptr<IO2GResponse> response = loginRules->getTableRefreshResponse(Offers);
        if (response)
        {
            O2G2Ptr<IO2GResponseReaderFactory> readerFactory = session->getResponseReaderFactory();
            if (readerFactory)
            {
                O2G2Ptr<IO2GOffersTableResponseReader> reader = readerFactory->createOffersTableReader(response);
                for (int i = 0; i < reader->size(); ++i)
                {
                    O2G2Ptr<IO2GOfferRow> offer = reader->getRow(i);
                    if (offer)
                    {
                        if (strcmp(offer->getSubscriptionStatus(), O2G2::SubscriptionStatuses::ViewOnly) == 0)
                            printf("%s : [V]iew only\n", offer->getInstrument());
                        else if (strcmp(offer->getSubscriptionStatus(), O2G2::SubscriptionStatuses::Disable) == 0)
                            printf("%s : [D]isabled\n", offer->getInstrument());
                        else if (strcmp(offer->getSubscriptionStatus(), O2G2::SubscriptionStatuses::Tradable) == 0)
                            printf("%s : Available for [T]rade\n", offer->getInstrument());
                        else
                            printf("%s : %s\n", offer->getInstrument(), offer->getSubscriptionStatus());
                        if (strcmp(offer->getInstrument(), sInstrument) == 0)
                            resultOffer = offer.Detach();
                    }
                }
            }
        }
    }
    return resultOffer;
}

// Subscribe or unsubscribe an instrument
IO2GRequest *createSetSubscriptionStatusRequest(IO2GSession *session, const char *sOfferID, const char *sStatus, ResponseListener *responseListener)
{
    O2G2Ptr<IO2GRequestFactory> requestFactory = session->getRequestFactory();
    if (!requestFactory)
    {
        std::cout << "Cannot create request factory" << std::endl;
        return NULL;
    }
    O2G2Ptr<IO2GValueMap> valuemap = requestFactory->createValueMap();
    valuemap->setString(Command, O2G2::Commands::SetSubscriptionStatus);
    valuemap->setString(SubscriptionStatus, sStatus);
    valuemap->setString(OfferID, sOfferID);
    O2G2Ptr<IO2GRequest> request = requestFactory->createOrderRequest(valuemap);
    if (!request)
    {
        std::cout << requestFactory->getLastError() << std::endl;
        return NULL;
    }
    return request.Detach();
}

// Get and print margin requirements

void printSampleParams(std::string &sProcName, LoginParams *loginParams, SampleParams *sampleParams)
{
    std::cout << "Running " << sProcName << " with arguments:" << std::endl;

    // Login (common) information
    if (loginParams)
    {
        std::cout << loginParams->getLogin() << " * "
                  << loginParams->getURL() << " "
                  << loginParams->getConnection() << " "
                  << loginParams->getSessionID() << " "
                  << loginParams->getPin() << std::endl;
    }

    // Sample specific information
    if (sampleParams)
    {
        std::cout << "Status='" << sampleParams->getStatus() << std::endl;
    }
}

void printHelp(std::string &sProcName)
{
    std::cout << sProcName << " sample parameters:" << std::endl << std::endl;
            
    std::cout << "/login | --login | /l | -l" << std::endl;
    std::cout << "Your user name." << std::endl << std::endl;
                
    std::cout << "/password | --password | /p | -p" << std::endl;
    std::cout << "Your password." << std::endl << std::endl;
                
    std::cout << "/url | --url | /u | -u" << std::endl;
    std::cout << "The server URL. For example, http://www.fxcorporate.com/Hosts.jsp." << std::endl << std::endl;
                
    std::cout << "/connection | --connection | /c | -c" << std::endl;
    std::cout << "The connection name. For example, \"Demo\" or \"Real\"." << std::endl << std::endl;
                
    std::cout << "/pin | --pin " << std::endl;
    std::cout << "Your pin code. Required only for users who have a pin. Optional parameter." << std::endl << std::endl;
                
    std::cout << "/status | --status " << std::endl;
    std::cout << "Desired subscription status of the instrument. Possible values: T, D, V." << std::endl << std::endl;
            
}

bool checkObligatoryParams(LoginParams *loginParams, SampleParams *sampleParams)
{
    /* Check login parameters. */
    if (strlen(loginParams->getLogin()) == 0)
    {
        std::cout << LoginParams::Strings::loginNotSpecified << std::endl;
        return false;
    }
    if (strlen(loginParams->getPassword()) == 0)
    {
        std::cout << LoginParams::Strings::passwordNotSpecified << std::endl;
        return false;
    }
    if (strlen(loginParams->getURL()) == 0)
    {
        std::cout << LoginParams::Strings::urlNotSpecified << std::endl;
        return false;
    }
    if (strlen(loginParams->getConnection()) == 0)
    {
        std::cout << LoginParams::Strings::connectionNotSpecified << std::endl;
        return false;
    }

    if (strlen(sampleParams->getStatus()) == 0)
    {
        std::cout << SampleParams::Strings::statusNotSpecified << std::endl;
        return false;
    }

    return true;
}

