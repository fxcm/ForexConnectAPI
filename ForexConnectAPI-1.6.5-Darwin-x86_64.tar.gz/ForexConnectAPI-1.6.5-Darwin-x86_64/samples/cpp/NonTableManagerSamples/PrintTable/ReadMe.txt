PrintTable application

Brief
===============================================================================
This sample shows how to get a table and print it.
The sample performs the following actions:
1. Logs in.
2. Prints the Accounts table.
3. Requests the Trades or Orders table refresh.
4. Prints the Trades or Orders table.
5. Logs out.

Building the application
===============================================================================
Windows:
    To build this application, you will need MS Visual Studio 2015.

    You can run fxbuild.bat (fxbuild64.bat for the 64-bit version) or select
    "build" in MS Visual Studio.

Linux/MacOS:
    To build this application, you will need:
        - gcc-4.3 or later
        - g++-4.3 or later
        - CMake 2.6 or later
        
To build the application, run fxbuild.sh.

Running the application
===============================================================================
You can run this application from the bin directory.
In Windows, you can run this application by executing fxrun.bat.
All arguments must be passed from the command line.
This will run the application and display the output in your console.

You can run the application with no arguments, this will show the
application Help.

Arguments
===============================================================================
/login | --login | /l | -l
Your user name.

/password | --password | /p | -p
Your password.

/url | --url | /u | -u
The server URL. For example, http://www.fxcorporate.com/Hosts.jsp.

/connection | --connection | /c | -c
The connection name. For example, Demo or Real.

/sessionid | --sessionid 
The database name. Required only for users who have accounts in more than one database. Optional argument.

/pin | --pin 
Your pin code. Required only for users who have pin codes. Optional argument.

/table | --table | /t | -t
The table to print. Possible values: orders - the Orders table, trades - the Trades table. Optional parameter. The default value is trades.