PrintTable application

Brief
==================================================================================
This sample shows how to get a table and print it.
The sample performs the following actions:
1. Logs in.
2. Prints the Accounts table.
3. Requests the Trades or Orders table refresh.
4. Print the Trades or Orders table.
5. Logs out.

Building the application
==================================================================================
To build this application, you will need MS Visual Studio 2017 or later and
.NET Core 1.0 or later.
You can download .NET Core from https://www.microsoft.com/net/download/core.

To build the application, run fxbuild.bat on Windows or fxbuild.sh on *nix.
To compile a debug build of the application, set the argument "Debug" via the command line.
The compiled files will be placed in the .\bin\netcoreapp1.0 directory.

Running the application
==================================================================================
To run the application, run fxrun.bat on Windows or fxrun.sh on *nix. 
The output will be displayed in your console.