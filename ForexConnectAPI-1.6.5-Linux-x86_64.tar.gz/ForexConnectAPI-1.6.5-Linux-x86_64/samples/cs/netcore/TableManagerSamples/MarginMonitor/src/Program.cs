using System;
using System.Threading;
using ArgParser;
using fxcore2;

namespace MarginMonitor
{
    class Program
    {
        static bool monitorThreadMustStop;

        static void Main(string[] args)
        {
            O2GSession session = null;
            SessionStatusListener statusListener = null;

            try
            {
                Console.WriteLine("MarginMonitor sample\n");

                ArgumentParser argParser = new ArgumentParser(args, "MarginMonitor");

                argParser.AddArguments(ParserArgument.Login,
                                       ParserArgument.Password,
                                       ParserArgument.Url,
                                       ParserArgument.Connection,
                                       ParserArgument.SessionID,
                                       ParserArgument.Pin,
                                       ParserArgument.AccountID);

                argParser.ParseArguments();

                if (!argParser.AreArgumentsValid)
                {
                    argParser.PrintUsage();
                    return;
                }

                argParser.PrintArguments();

                LoginParams loginParams = argParser.LoginParams;
                SampleParams sampleParams = argParser.SampleParams;

                session = O2GTransport.createSession();
                session.useTableManager(O2GTableManagerMode.Yes, null);
                statusListener = new SessionStatusListener(session, loginParams.SessionID, loginParams.Pin);
                session.subscribeSessionStatus(statusListener);
                statusListener.Reset();
                session.login(loginParams.Login, loginParams.Password, loginParams.URL, loginParams.Connection);
                if (statusListener.WaitEvents() && statusListener.Connected)
                {
                    O2GTableManager tableManager = session.getTableManager();
                    O2GTableManagerStatus managerStatus = tableManager.getStatus();
                    while (managerStatus == O2GTableManagerStatus.TablesLoading)
                    {
                        Thread.Sleep(50);
                        managerStatus = tableManager.getStatus();
                    }

                    if (managerStatus == O2GTableManagerStatus.TablesLoadFailed)
                    {
                        throw new Exception("Cannot refresh all tables of table manager");
                    }

                    O2GAccountTableRow account = GetAccount(tableManager, sampleParams.AccountID);
                    if (account == null)
                    {
                        if (string.IsNullOrEmpty(sampleParams.AccountID))
                        {
                            throw new Exception("No valid accounts");
                        }
                        else
                        {
                            throw new Exception(string.Format("The account {0} is not valid", sampleParams.AccountID));
                        }
                    }
                    sampleParams.AccountID = account.AccountID;
                    Console.WriteLine("Account: {0}", sampleParams.Instrument);

                    DoWork(session, sampleParams, tableManager, account);

                    statusListener.Reset();
                    session.logout();
                    statusListener.WaitEvents();

                    Console.WriteLine("Done!");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: {0}", e.ToString());
            }
            finally
            {
                if (session != null)
                {
                    if (statusListener.Connected)
                    {
                        statusListener.Reset();
                        session.logout();
                        statusListener.WaitEvents();
                    }
                    session.unsubscribeSessionStatus(statusListener);
                    session.Dispose();
                }
            }
        }

        private static void DoWork(O2GSession session, SampleParams sampleParams, O2GTableManager tableManager, O2GAccountTableRow account)
        {
            O2GLoginRules loginRules = session.getLoginRules();
            if (loginRules == null)
                throw new Exception("Cannot get login rules");

            O2GOfferRow offer = GetOffer(tableManager, sampleParams.Instrument);
            if (offer == null)
                throw new Exception(string.Format("The instrument {0} not found", sampleParams.Instrument));

            O2GTradingSettingsProvider tradingSettingsProvider = loginRules.getTradingSettingsProvider();
            string instrument = offer.Instrument;
            bool isProgressiveMargin = tradingSettingsProvider.isProgressiveMargin(instrument, account);

            if (isProgressiveMargin)
            {
                Console.WriteLine(string.Format("Instrument {0} is under progressive margin requirements.", instrument));
                O2GProgressiveMarginLevels levels = tradingSettingsProvider.getProgressiveMarginLevels(instrument, account);

                PrintProgressiveMarginLevels(levels);
            }
            else
            {
                Console.WriteLine(string.Format("Progressive margin is not applicable to {0}.", instrument));
            }

            Thread marginMonitorThread = new Thread(() =>
            {
                try
                {
                    StartMarginMonitor(tableManager, sampleParams, tradingSettingsProvider);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception: {0}", e.ToString());
                }

            });

            marginMonitorThread.Start();

            // continue update the data until cancelled by a user
            Console.WriteLine("Press ENTER to cancel");
            Console.ReadKey();

            monitorThreadMustStop = true;
            marginMonitorThread.Join();
        }

        private static void StartMarginMonitor(O2GTableManager tableManager, SampleParams sampleParams, O2GTradingSettingsProvider tradingSettingsProvider)
        {
            O2GAccountTableRow account = GetAccount(tableManager, sampleParams.AccountID);
            if (account == null)
                throw new Exception("No valid accounts");

            string instrument = sampleParams.Instrument;

            O2GOfferRow offer = GetOffer(tableManager, instrument);
            if (offer == null)
                throw new Exception(string.Format("The instrument {0} not found", sampleParams.Instrument));

            while (!monitorThreadMustStop)
            {
                Thread.Sleep(1000);

                //refresh account row
                account = GetAccount(tableManager, sampleParams.AccountID);
                if (account != null)
                {
                    PrintOfferMargin(tradingSettingsProvider, account, instrument);
                    PrintAccountMargin(account);
                }

                O2GTradesTable tradesTable = (O2GTradesTable)tableManager.getTable(O2GTableType.Trades);
                PrintTradesMargin(tradesTable, instrument);

                O2GSummaryTableRow summary = GetSummary(tableManager, instrument);
                if (summary != null)
                {
                    PrintSummaryMargin(summary, instrument);
                }
            }
            Console.WriteLine("Margin monitor was stopped");
        }

        private static void PrintSummaryMargin(O2GSummaryTableRow summary, string instrument)
        {
            if (summary != null)
            {
                Console.WriteLine("Summary:");

                Console.WriteLine(string.Format("UsedMargin[ {0} ]: {1:0.00}", instrument, summary.UsedMargin));
                Console.WriteLine(string.Format("UsedMarginBuy[ {0} ]: {1:0.00}", instrument, summary.UsedMarginBuy));
                Console.WriteLine(string.Format("UsedMarginSell[ {0} ]: {1:0.00}", instrument, summary.UsedMarginSell));

                Console.WriteLine("---- ");
            }
        }

        private static void PrintTradesMargin(O2GTradesTable tradesTable, string instrument)
        {
            if (tradesTable.Count > 0)
            {
                Console.WriteLine("Trades:");

                O2GTableIterator tradesIterator = new O2GTableIterator();
                O2GTradeTableRow tradeRow = null;
                bool hasNextRow = true;
                while (true)
                {
                    hasNextRow = tradesTable.getNextRow(tradesIterator, out tradeRow);
                    if (!hasNextRow) break;

                    if (!string.IsNullOrEmpty(instrument) && instrument == tradeRow.Instrument)
                        Console.WriteLine(string.Format("TradeID: {0}    UsedMargin: {1:0.00}", tradeRow.TradeID, tradeRow.UsedMargin));
                }

                Console.WriteLine("---- ");
            }
        }

        private static void PrintAccountMargin(O2GAccountTableRow account)
        {
            Console.WriteLine("Account:");

            Console.WriteLine(string.Format("UsedMargin: {0:0.00}", account.UsedMargin));
            Console.WriteLine(string.Format("UsedMargin3: {0:0.00}", account.UsedMargin3));

            Console.WriteLine("---- ");
        }

        private static void PrintOfferMargin(O2GTradingSettingsProvider tradingSettingsProvider, O2GAccountRow account, String instrument)
        {

            bool isTier3 = tradingSettingsProvider.isTier3(account);

            Console.WriteLine("Offers:");
            if (isTier3)
            {
                double mmr = 0, emr = 0, lmr = 0;
                tradingSettingsProvider.getMargins(instrument, account, ref mmr, ref emr, ref lmr);
                Console.WriteLine(string.Format("MMR: {0:0.00}, EMR: {1:0.00}, LMR: {2:0.00}", mmr, emr, lmr));
            }
            else
            {
                double mmr = tradingSettingsProvider.getMMR(instrument, account);
                Console.WriteLine(string.Format("MMR: {0:0.00}", mmr));
            }

            Console.WriteLine("---- ");
        }

        private static void PrintProgressiveMarginLevels(O2GProgressiveMarginLevels levels)
        {
            Console.WriteLine("Levels: ");
            for (int i = 0; i < levels.getCount(); ++i)
            {
                int from = levels.getFrom(i);
                int till = levels.getTill(i);
                double multiplier = levels.getMarginPerContract(i);

                Console.Write(string.Format("From: {0}", from));
                if (till != -1)
                    Console.WriteLine(string.Format("\nTill: {0}", till));
                else
                    Console.WriteLine("+ ");

                Console.WriteLine(string.Format(" Margin per contract: {0:0.00}", multiplier));
            }
        }

        /// <summary>
        /// Find valid account
        /// </summary>
        /// <param name="tableManager"></param>
        /// <returns>account</returns>
        private static O2GAccountTableRow GetAccount(O2GTableManager tableManager, string sAccountID)
        {
            bool bHasAccount = false;
            O2GAccountTableRow account = null;
            O2GAccountsTable accountsTable = (O2GAccountsTable)tableManager.getTable(O2GTableType.Accounts);
            for (int i = 0; i < accountsTable.Count; i++)
            {
                account = accountsTable.getRow(i);
                string sAccountKind = account.AccountKind;
                if (sAccountKind.Equals("32") || sAccountKind.Equals("36"))
                {
                    if (account.MarginCallFlag.Equals("N"))
                    {
                        if (string.IsNullOrEmpty(sAccountID) || sAccountID.Equals(account.AccountID))
                        {
                            bHasAccount = true;
                            break;
                        }
                    }
                }
            }
            if (!bHasAccount)
            {
                return null;
            }
            else
            {
                return account;
            }
        }

        /// <summary>
        /// Find valid offer by instrument name
        /// </summary>
        /// <param name="tableManager"></param>
        /// <param name="sInstrument"></param>
        /// <returns>offer</returns>
        private static O2GOfferRow GetOffer(O2GTableManager tableManager, string sInstrument)
        {
            bool bHasOffer = false;
            O2GOfferRow offer = null;
            O2GOffersTable offersTable = (O2GOffersTable)tableManager.getTable(O2GTableType.Offers);
            for (int i = 0; i < offersTable.Count; i++)
            {
                offer = offersTable.getRow(i);
                if (offer.Instrument.Equals(sInstrument))
                {
                    if (offer.SubscriptionStatus.Equals("T"))
                    {
                        bHasOffer = true;
                        break;
                    }
                }
            }
            if (!bHasOffer)
            {
                return null;
            }
            else
            {
                return offer;
            }
        }
        /// <summary>
        /// Find summary table row by instrument name
        /// </summary>
        /// <param name="tableManager"></param>
        /// <param name="instrument"></param>
        /// <returns>summary table row</returns>
        private static O2GSummaryTableRow GetSummary(O2GTableManager tableManager, string instrument)
        {
            bool bHasSummary = false;
            O2GSummaryTableRow summaryRow = null;
            O2GSummaryTable summaryTable = (O2GSummaryTable)tableManager.getTable(O2GTableType.Summary);
            for (int i = 0; i < summaryTable.Count; i++)
            {
                summaryRow = summaryTable.getRow(i);
                if (summaryRow.Instrument == instrument)
                {
                    bHasSummary = true;
                    break;
                }
            }
            if (!bHasSummary)
            {
                return null;
            }
            else
            {
                return summaryRow;
            }
        }

        
    }
}