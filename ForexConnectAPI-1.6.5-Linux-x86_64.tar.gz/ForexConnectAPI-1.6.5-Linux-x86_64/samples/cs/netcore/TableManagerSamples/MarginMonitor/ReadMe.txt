MarginMonitor application

Brief
===============================================================================
This sample shows how to monitor margin changes in the Offers, Accounts, Trades,
and Summary tables.

This application performs the following actions:
1. Login.
2. Print the progressive margin levels for the specified instrument if it is under progressive margin requirements.
3. Print the used maintenance margin for the specified instrument.
4. Print the account used margin and used maintenance margin.
5. Print the used margin for each trade in the specified instrument.
6. Print the used margin for all trades in the specified instrument.
7. Logout.

Building the application
==================================================================================
In order to build this application you will need MS Visual Studio 2017 or later and
.NET Core 1.0 or later.
You can download .NET Core from https://www.microsoft.com/net/download/core
To build the application run fxbuild.bat on Windows or fxbuild.sh on *nix.
To compile the application into a debug build set argument "Debug" via command line.
Compiled files will be placed in .\bin\netcoreapp1.0 directory.

Running the application
==================================================================================
To run the application you must run fxrun.bat on Windows or fxrun.sh on *nix. 
The output will be displayed on your console.
