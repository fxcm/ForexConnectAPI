example program how to change Stop and Limit for open position,
If there is no Stop or Limit for the Ticket# it will create Stop and/or Limit 
If Stop and Limit exists the program will change both Stop and Limit with prices in the App.config file
Parameters for the program:
    
    <add key="Login" value="D101546502111"/>
    <add key="Password" value="1111" />
    <add key="URL" value="www.fxcorporate.com/Hosts.jsp"/>
    <add key="Connection" value="Demo"/>
    <add key="SessionID" value=""/>
    <add key="Pin" value=""/>

    <add key="Account" value="1549059"/>
    <add key="TradeID" value="79878935"/>

    <add key="RateStop" value="1.08113"/>
    <add key="RateLimit" value="1.1113"/>
