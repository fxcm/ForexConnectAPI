using System;
using System.Collections.Specialized;
using System.Text;
using System.Configuration;
using System.Threading;
using fxcore2;


namespace ChangePositionStopLimit
{
    class Program
    {
        static void Main(string[] args)
        {
            O2GSession session = null;
            string limitOrderID = "", stopOrderID = "";

            try
            {
                LoginParams loginParams = new LoginParams(ConfigurationManager.AppSettings);
                SampleParams sampleParams = new SampleParams(ConfigurationManager.AppSettings);

                PrintSampleParams("CreateStopLimitForEntry", loginParams, sampleParams);

                session = O2GTransport.createSession();
                SessionStatusListener statusListener = new SessionStatusListener(session, loginParams.SessionID, loginParams.Pin);
                session.subscribeSessionStatus(statusListener);
                statusListener.Reset();
                session.login(loginParams.Login, loginParams.Password, loginParams.URL, loginParams.Connection);
                if (statusListener.WaitEvent() && statusListener.Connected)
                {
                    ResponseListener responseListener = new ResponseListener(session);
                    session.subscribeResponse(responseListener);

                    O2GAccountRow account = GetAccount(session, sampleParams.AccountID);
                    if (account == null)
                    {
                        if (string.IsNullOrEmpty(sampleParams.AccountID))
                        {
                            throw new Exception("No valid accounts");
                        }
                        else
                        {
                            throw new Exception(string.Format("The account '{0}' is not valid", sampleParams.AccountID));
                        }
                    }

                    O2GTradeRow tradeRow = FindTrade(session, sampleParams.AccountID, sampleParams.TradeID, responseListener);
                    if (tradeRow == null)
                    {
                        throw new Exception("wrong Ticket# " + sampleParams.TradeID);
                    }


                    FindStopLimitOrders(session, sampleParams.AccountID, sampleParams.TradeID, responseListener, ref limitOrderID, ref stopOrderID);

                    //if Limit and Order already exeists
                    if (limitOrderID != "" && stopOrderID != "")
                    {
                        O2GRequest request = ChangeTradeLimitStop(session, sampleParams.AccountID, limitOrderID, sampleParams.RateLimit);
                        if (request == null)
                        {
                            throw new Exception("Cannot create request");
                        }
                        responseListener.SetRequestID(request.RequestID);
                        session.sendRequest(request);
                        Thread.Sleep(100);

                        request = ChangeTradeLimitStop(session, sampleParams.AccountID, stopOrderID, sampleParams.RateStop);
                        if (request == null)
                        {
                            throw new Exception("Cannot create request");
                        }
                        responseListener.SetRequestID(request.RequestID);
                        session.sendRequest(request);
                        Thread.Sleep(100);
                    }

                    //if no Limit price
                    if (limitOrderID == "")
                    {
                        O2GRequest request = AddOrderForEntryRequest(session, tradeRow, "L", sampleParams.RateLimit);
                        if (request == null)
                        {
                            throw new Exception("Cannot create request limitOrderID");
                        }
                        responseListener.SetRequestID(request.RequestID);
                        session.sendRequest(request);
                        Thread.Sleep(100);
                    }


                    if (stopOrderID == "")
                    {
                        O2GRequest request = AddOrderForEntryRequest(session, tradeRow, "S", sampleParams.RateStop);
                        if (request == null)
                        {
                            throw new Exception("Cannot create request stopOrderID");
                        }
                        responseListener.SetRequestID(request.RequestID);
                        session.sendRequest(request);
                        Thread.Sleep(100);
                    }


                    Console.WriteLine("Done!");
                    statusListener.Reset();
                    session.logout();
                    statusListener.WaitEvent();
                    session.unsubscribeResponse(responseListener);
                }
                session.unsubscribeSessionStatus(statusListener);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: {0}", e.ToString());
            }
            finally
            {
                if (session != null)
                {
                    session.Dispose();
                }
            }
        }

        /// <summary>
        /// Find valid account
        /// </summary>
        private static O2GAccountRow GetAccount(O2GSession session, string sAccountID)
        {
            O2GAccountRow account = null;
            bool bHasAccount = false;
            O2GResponseReaderFactory readerFactory = session.getResponseReaderFactory();
            if (readerFactory == null)
            {
                throw new Exception("Cannot create response reader factory");
            }
            O2GLoginRules loginRules = session.getLoginRules();
            O2GResponse response = loginRules.getTableRefreshResponse(O2GTableType.Accounts);
            O2GAccountsTableResponseReader accountsResponseReader = readerFactory.createAccountsTableReader(response);
            for (int i = 0; i < accountsResponseReader.Count; i++)
            {
                account = accountsResponseReader.getRow(i);
                string sAccountKind = account.AccountKind;
                if (sAccountKind.Equals("32") || sAccountKind.Equals("36"))
                {
                    if (account.MarginCallFlag.Equals("N"))
                    {
                        if (string.IsNullOrEmpty(sAccountID) || sAccountID.Equals(account.AccountID))
                        {
                            bHasAccount = true;
                            break;
                        }
                    }
                }
            }
            if (!bHasAccount)
            {
                return null;
            }
            else
            {
                return account;
            }
        }


        /// <summary>
        /// Get order by trade ID
        /// </summary>
        private static O2GTradeRow FindTrade(O2GSession session, string sAccountID, string sTradeID, ResponseListener responseListener)
        {
            O2GRequestFactory requestFactory = session.getRequestFactory();
            if (requestFactory == null)
            {
                throw new Exception("Cannot create request factory");
            }
            O2GRequest request = requestFactory.createRefreshTableRequestByAccount(O2GTableType.Trades, sAccountID);
            if (request != null)
            {
                responseListener.SetRequestID(request.RequestID);
                session.sendRequest(request);
                if (!responseListener.WaitEvents())
                {
                    throw new Exception("Response waiting timeout expired");
                }
                O2GResponse tradeResponse = responseListener.GetResponse();
                if (tradeResponse != null)
                {
                    if (tradeResponse.Type == O2GResponseType.GetTrades)
                    {
                        O2GResponseReaderFactory responseReaderFactory = session.getResponseReaderFactory();
                        O2GTradesTableResponseReader responseReader = responseReaderFactory.createTradesTableReader(tradeResponse);
                        for (int i = 0; i < responseReader.Count; i++)
                        {
                            //O2GOrderRow orderRow = responseReader.getRow(i);
                            O2GTradeRow tradeRow = responseReader.getRow(i);
                            if (sTradeID.Equals(tradeRow.TradeID))
                            {
                                return tradeRow;
                            }
                        }
                    }
                }
            }
            return null;
        }


        private static void FindStopLimitOrders(O2GSession session, string sAccountID, string sTradeID, ResponseListener responseListener, ref string buyOrderID, ref string sellOrderID)
        {
            O2GRequestFactory requestFactory = session.getRequestFactory();
            if (requestFactory == null)
            {
                throw new Exception("Cannot create request factory");
            }
            O2GRequest request = requestFactory.createRefreshTableRequestByAccount(O2GTableType.Orders, sAccountID);
            if (request != null)
            {
                responseListener.SetRequestID(request.RequestID);
                session.sendRequest(request);
                if (!responseListener.WaitEvents())
                {
                    throw new Exception("Response waiting timeout expired");
                }
                O2GResponse orderResponse = responseListener.GetResponse();
                if (orderResponse != null)
                {
                    if (orderResponse.Type == O2GResponseType.GetOrders)
                    {
                        O2GResponseReaderFactory responseReaderFactory = session.getResponseReaderFactory();
                        O2GOrdersTableResponseReader responseReader = responseReaderFactory.createOrdersTableReader(orderResponse);
                        for (int i = 0; i < responseReader.Count; i++)
                        {
                            O2GOrderRow orderRow = responseReader.getRow(i);
                            if (sTradeID.Equals(orderRow.TradeID))
                            {
                                if (orderRow.Type == "L")
                                    buyOrderID = orderRow.OrderID;

                                if (orderRow.Type == "S")
                                    sellOrderID = orderRow.OrderID;
                            }
                        }
                    }
                }
            }
        }



        /// <summary>
        /// change L or S order to existing entry trade
        /// </summary>
        private static O2GRequest ChangeTradeLimitStop(O2GSession session, string account, string orderID, double dRate)
        {
           
            O2GRequestFactory requestFactory = session.getRequestFactory();
            if (requestFactory == null)
            {
                throw new Exception("Cannot create request factory");
            }
            O2GValueMap valuemap = requestFactory.createValueMap();
            valuemap.setString(O2GRequestParamsEnum.Command, Constants.Commands.EditOrder);
            valuemap.setDouble(O2GRequestParamsEnum.Rate, dRate);
            valuemap.setString(O2GRequestParamsEnum.AccountID, account);
            valuemap.setString(O2GRequestParamsEnum.OrderID, orderID);
            O2GRequest request = requestFactory.createOrderRequest(valuemap);
            if (request == null)
            {
                Console.WriteLine(requestFactory.getLastError());
            }

            return(request);
        }


        /// <summary>
        /// Attach L or S order to existing entry trade
        /// </summary>
        private static O2GRequest AddOrderForEntryRequest(O2GSession session, O2GTradeRow tradeRow, string sOrderType, double dRate)
        {
            if (!sOrderType.Equals("L") && !sOrderType.Equals("S"))
            {
                throw new Exception("Incorrect order type");
            }
            O2GRequest request = null;
            O2GRequestFactory requestFactory = session.getRequestFactory();
            if (requestFactory == null)
            {
                throw new Exception("Cannot create request factory");
            }
            O2GValueMap valuemap = requestFactory.createValueMap();
            valuemap.setString(O2GRequestParamsEnum.Command, Constants.Commands.CreateOrder);
            valuemap.setString(O2GRequestParamsEnum.OrderType, sOrderType); // Must be L or S
            valuemap.setString(O2GRequestParamsEnum.OfferID, tradeRow.OfferID);
            string sOppositeDirection = tradeRow.BuySell == Constants.Buy ? Constants.Sell : Constants.Buy;
            valuemap.setString(O2GRequestParamsEnum.BuySell, sOppositeDirection); // The order direction must be opposite to the direction of the order which was used to create the position
            valuemap.setInt(O2GRequestParamsEnum.Amount, tradeRow.Amount);
            valuemap.setString(O2GRequestParamsEnum.CustomID, "AttachedEntryOrder");
            valuemap.setDouble(O2GRequestParamsEnum.Rate, dRate);
            valuemap.setString(O2GRequestParamsEnum.AccountID, tradeRow.AccountID);
            valuemap.setString(O2GRequestParamsEnum.TradeID, tradeRow.TradeID);
            request = requestFactory.createOrderRequest(valuemap);
            if (request == null)
            {
                Console.WriteLine(requestFactory.getLastError());
            }
            return (request);
        }

        /// <summary>
        /// Print process name and sample parameters
        /// </summary>
        /// <param name="procName"></param>
        /// param name="loginPrm"></param>
        /// <param name="prm"></param>
        private static void PrintSampleParams(string procName, LoginParams loginPrm, SampleParams prm)
        {
            Console.WriteLine("{0}:, AccountID='{1}'", procName, prm.AccountID);
        }

        class LoginParams
        {
            public string Login
            {
                get
                {
                    return mLogin;
                }
            }
            private string mLogin;

            public string Password
            {
                get
                {
                    return mPassword;
                }
            }
            private string mPassword;

            public string URL
            {
                get
                {
                    return mURL;
                }
            }
            private string mURL;

            public string Connection
            {
                get
                {
                    return mConnection;
                }
            }
            private string mConnection;

            public string SessionID
            {
                get
                {
                    return mSessionID;
                }
            }
            private string mSessionID;

            public string Pin
            {
                get
                {
                    return mPin;
                }
            }
            private string mPin;

            /// <summary>
            /// ctor
            /// </summary>
            /// <param name="args"></param>
            public LoginParams(NameValueCollection args)
            {
                mLogin = GetRequiredArgument(args, "Login");
                mPassword = GetRequiredArgument(args, "Password");
                mURL = GetRequiredArgument(args, "URL");
                if (!string.IsNullOrEmpty(mURL))
                {
                    if (!mURL.EndsWith("Hosts.jsp", StringComparison.OrdinalIgnoreCase))
                    {
                        mURL += "/Hosts.jsp";
                    }
                }
                mConnection = GetRequiredArgument(args, "Connection");
                mSessionID = args["SessionID"];
                mPin = args["Pin"];
            }

            /// <summary>
            /// Get required argument from configuration file
            /// </summary>
            /// <param name="args">Configuration file key-value collection</param>
            /// <param name="sArgumentName">Argument name (key) from configuration file</param>
            /// <returns>Argument value</returns>
            private string GetRequiredArgument(NameValueCollection args, string sArgumentName)
            {
                string sArgument = args[sArgumentName];
                if (!string.IsNullOrEmpty(sArgument))
                {
                    sArgument = sArgument.Trim();
                }
                if (string.IsNullOrEmpty(sArgument))
                {
                    throw new Exception(string.Format("Please provide {0} in configuration file", sArgumentName));
                }
                return sArgument;
            }
        }

        class SampleParams
        {
            public double RateStop
            {
                get
                {
                    return mRateStop;
                }
            }
            private double mRateStop;

            public double RateLimit
            {
                get
                {
                    return mRateLimit;
                }
            }
            private double mRateLimit;

            public string OrderType
            {
                get
                {
                    return mOrderType;
                }
            }
            private string mOrderType;

            public string TradeID
            {
                get
                {
                    return mTradeID;
                }
                set
                {
                    mTradeID = value;
                }
            }
            private string mTradeID;


            public string AccountID
            {
                get
                {
                    return mAccountID;
                }
                set
                {
                    mAccountID = value;
                }
            }
            private string mAccountID;


            /// <summary>
            /// ctor
            /// </summary>
            /// <param name="args"></param>
            public SampleParams(NameValueCollection args)
            {
                mRateStop = Convert.ToDouble(GetRequiredArgument(args, "RateStop"));
                mRateLimit = Convert.ToDouble(GetRequiredArgument(args, "RateLimit"));
                mTradeID = GetRequiredArgument(args, "TradeID");
                mAccountID = args["Account"];
            }

            /// <summary>
            /// Get required argument from configuration file
            /// </summary>
            /// <param name="args">Configuration file key-value collection</param>
            /// <param name="sArgumentName">Argument name (key) from configuration file</param>
            /// <returns>Argument value</returns>
            private string GetRequiredArgument(NameValueCollection args, string sArgumentName)
            {
                string sArgument = args[sArgumentName];
                if (!string.IsNullOrEmpty(sArgument))
                {
                    sArgument = sArgument.Trim();
                }
                if (string.IsNullOrEmpty(sArgument))
                {
                    throw new Exception(string.Format("Please provide {0} in configuration file", sArgumentName));
                }
                return sArgument;
            }
        }

    }
}
