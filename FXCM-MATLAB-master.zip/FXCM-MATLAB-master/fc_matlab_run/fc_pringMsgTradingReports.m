%display execution reports messages 
function k = fc_pringMsgTradingReports(fc_msg, msgType )
    k = 1;
    display(fc_msg);
    %display(msgType);
end

