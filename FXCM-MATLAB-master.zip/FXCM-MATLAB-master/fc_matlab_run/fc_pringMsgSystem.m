%display login/logout messages 
function k = fc_pringMsgSystem(fc_msg, msgType )
    k = 1;
    display(fc_msg);
    %display(msgType);
end

