
void cb_sendMsg(char *msg, int msgType);


