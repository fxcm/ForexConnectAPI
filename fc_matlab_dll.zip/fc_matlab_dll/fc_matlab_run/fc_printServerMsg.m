function k = fc_printServerMsg(msg, msgType )
    k = 1;
    display(msg);
    display(msgType);
    if (msgType == 1)
        
end

