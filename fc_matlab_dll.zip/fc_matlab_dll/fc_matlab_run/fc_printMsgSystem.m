%display login/logout messages 
function k = fc_printMsgSystem(fc_msg, fc_msgType )
    k = 1;
    display(fc_msg);
    display(fc_msgType);
end

