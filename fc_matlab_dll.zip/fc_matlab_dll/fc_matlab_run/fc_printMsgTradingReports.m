%display execution reports messages 
function k = fc_printMsgTradingReports(fc_msg )
    k = 1;
    display(fc_msg);
    %display(msgType);
end

