unloadlibrary fc_matlab
